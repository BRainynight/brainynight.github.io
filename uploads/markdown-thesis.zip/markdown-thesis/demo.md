---
reference-doc: render-sample.dotx
link-bibliography: true
link-citations: true
fignos-cleveref: true
fignos-plus-name: 圖
fignos-caption-name: 圖
fignos-number-by-section: true
tablenos-cleveref: true
tablenos-plus-name: 表
tablenos-caption-name: 表
tablenos-number-by-section: true
eqnos-cleveref: true
eqnos-number-by-section: true
eqnos-plus-name: 公式
output:
  pdf_document:
    latex_engine: xelatex
lof: true 
lot: true
toc: true
---

# 摘要

根據文獻[@book1]所言，今天天氣真好。而文獻[@art1]提到，太陽會影響天氣。文獻[@col1]更是提到不但太陽會影響天氣，下雨、風也會。


\newpage



# 緒論

## 研究背景與動機

贊科夫說過一句很有意思的話，勞動教學裡，還能培養這樣一些寶貴的個性品質，如學會集體工作、熱愛勞動、克服困難的堅毅精神等。這段話雖短，卻足以改變人類的歷史。文獻回顧改變了我的命運。

## 文獻回顧

 深入的探討文獻回顧，是釐清一切的關鍵。我們普遍認為，若能理解透徹核心原理，對其就有了一定的了解程度。文獻回顧，到底應該如何實現。需要考慮周詳文獻回顧的影響及因應對策。

```{=openxml}
<w:p>
  <w:r>
    <w:br w:type="page"/>
  </w:r>
</w:p>
```

文獻回顧可以說是有著成為常識的趨勢。我們需要淘汰舊有的觀念，誇美紐斯曾講過，一株樹在最初的幾年中就從自己的樹幹中發出了它以後要有的一切主要的枝芽，而以後他們僅僅是繁茂起來而已。同樣，我們想賦予一個人一生所有的那些東西，也應當在這個最初的學校（母育學校）中賦予他們。這段話非常有意思。

## 研究目標

莫里哀曾經說過，不害相思，幸福就沒你的份。把愛情趕出了生活，你就趕出歡樂。一帆風順的愛情，其實寡味。這啟發了我。研究目標勢必能夠左右未來。若到今天結束時我們都還無法釐清研究目標的意義，那想必我們昨天也無法釐清。這種事實對本人來說意義重大，相信對這個世界也是有一定意義的。

## 論文架構

 陀思妥耶夫斯基說過一句發人省思的話，對具有高度自覺與深邃透徹的心靈的人來說，痛苦與煩惱是他必備的氣質。這句話看似簡單，卻埋藏了深遠的意義。論文架構可以說是有著成為常識的趨勢。這必定是個前衛大膽的想法。西塞羅深信，假如你有天賦，勤奮會使它變得更。這段話令我陷入了沈思。

 <div style="page-break-after: always;"></div>

# 參照介紹

## 表格介紹

|        | 降雨 | 氣溫 |
| --- | --- | --- |
| 星期一 | 80％ | 27   |
| 星期二 | 90%  | 16   |
| 星期三 | 10%  | 20   |
Table: 降雨機率 {#tbl:tbl1}

星期三天氣晴朗，有機會看到如 {@fig:fig1} 一般的景色。



##  圖介紹

![天氣晴朗時的風景](example-fig.jpg){#fig:fig1}

晴朗與否，請參考 {@tbl:tbl1}

## 公式呼叫
直線函數之公式為  $$ y = mx + b $${#eq:line} 而多項式為

$$
y = \sum_{n=0}^{\infty} a_n x^n
$$ {#eq:polynomial}

{@eq:line} 與 {@eq:polynomial} 都是基於笛卡兒坐標系的數學，然而向牽扯到極座標系與笛卡兒坐標系，事情就變得無比複雜

$$
y = A e^{-\gamma t}\cos(2\pi f t)
$$ {#eq:}

其中，$$ \pi = 3.141592653589793238462643 \ldots $$ ，沒有添加上 `{#eq}` 的公式就不會進行標號! 像是 $\pi$ 就是如此。



# 參考文獻





